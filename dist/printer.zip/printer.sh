java -jar printer.jar -Xms1024M
